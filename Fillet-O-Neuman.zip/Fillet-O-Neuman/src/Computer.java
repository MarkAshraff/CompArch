import java.io.File;
import java.util.Scanner;

public class Computer {
	int pc;
	int[] registerFile;
	int[] memory;
	String s;
	String [] st;
	int cycles;
	ins IF;
	ins ID;
	ins exc;
	ins mem;
	ins wb;
	int count;
	boolean fetchJMP;
	boolean dfetch;
	boolean branch;
	int old;
	String [] tobeprinted;
	
	public Computer() {
		
		tobeprinted=new String[5];
		
		registerFile = new int[32];
		memory = new int[2048];
		pc = 0;
		cycles = 0;
		count=0;
		fetchJMP = false;
		dfetch = false;
		branch = false;
		old = -1;
		
	}
	public void Cycle() throws Exception {
		if(wb!= null) {
			
			
			wb.WriteBack();
			
			tobeprinted[4]="";
			tobeprinted[4]+=	"Instruction in Write Back stage is : "+wb.instr+'\n';
			tobeprinted[4]+="Input is : "+wb.output+'\n';
			if(wb.opcode != 11 && wb.opcode!=7 && wb.opcode!=4) {
				if(wb.r1 == 0) {
					tobeprinted[4]+="Value of register R0 remained zero"+'\n'+'\n';
					
				}
				else {
					tobeprinted[4]+="Value of register R"+wb.r1+" changed to "+wb.output+'\n'+'\n';
					
				}
			}
			if(wb.opcode==7) {
				fetchJMP = true;
			}
			if(wb.opcode==4 && branch) {
				fetchJMP = true;
				branch = false;
			}
			wb = null;
		}
		else {
			
			tobeprinted[4]="";

			tobeprinted[4]+="No instruction in Write Back stage"+'\n'+'\n';
			
		}
		if(mem != null) {
			
			if(mem.opcode == 7) {
				IF = null;
				exc= null;
			}
			if(mem.opcode == 4 && branch) {
				IF = null;
				exc = null;
			}
	

			mem.Memory();

			tobeprinted[3]="";

			tobeprinted[3]+="Instruction in Memory stage is : "+mem.instr+'\n';
			tobeprinted[3]+="Input : Address = "+mem.output+'\n';
	        if(mem.opcode == 10) {
	        	tobeprinted[3]+="Value retrieved from memory = "+mem.output+'\n';
	        }
	        else if(mem.opcode == 11) {
	        	tobeprinted[3]+="Value of memory location  "+mem.output+" Changed to "+registerFile[mem.r1]+'\n'+'\n';
	        }
	        else {
	        	tobeprinted[3]+="No Output"+'\n';
	        }

			wb = mem;
			wb.c=this;
			mem = null;
		}
		else {
			tobeprinted[3]="";

			tobeprinted[3]+=("No instruction in memory stage")+'\n'+'\n';
			System.out.println(" ");
		}
		if(exc != null) {
			if(exc.timer == 0) {
				
				if(exc.opcode==7 || (exc.opcode==4 && (registerFile[exc.r1] == exc.valueR2))) {
					  IF = new ins();
					    IF.c=this;
						IF.instr=memory[pc];

						tobeprinted[0]="";

						tobeprinted[0]+="Instruction in Fetch stage is : "+IF.instr+'\n';
						
						tobeprinted[0]+="Input is PC = "+pc+'\n';
						tobeprinted[0]+=	"Output is : "+IF.instr+'\n'+'\n';
							
						IF=null;
				}

				exc.execute();
				
				tobeprinted[2]="";

				tobeprinted[2]+=	("Instruction in Execute stage is : "+exc.instr)+'\n';
				if(exc.opcode == 1 || exc.opcode == 2 || exc.opcode == 0 || exc.opcode ==5) {
					tobeprinted[2]+=	"Inputs are : Value of source register "+exc.valueR2+" and Value of target register "+exc.valueR3+'\n';
				}
				if(exc.opcode ==3) {
					tobeprinted[2]+=	"Input is immediate value: "+exc.imm+'\n';
				}
				if(exc.opcode == 6 || exc.opcode == 10 || exc.opcode == 11) {
					tobeprinted[2]+="Inputs : Value of source register "+exc.valueR2+" and immediate value "+exc.imm+'\n';
				}
				if(exc.opcode == 8 || exc.opcode == 9) {
					tobeprinted[2]+="Inputs : value of source register "+exc.valueR2+" and shift amount "+exc.shamt+'\n';
				}
				if(exc.opcode==7) {
					tobeprinted[2]+="Input : address = "+exc.addr+'\n';
					dfetch=true;
				}
				if(exc.opcode == 4) {
					tobeprinted[2]+="Input : Value of source register "+registerFile[exc.r1]+" and value of target register"+exc.valueR2+'\n';
				}
				if(exc.opcode==4 && branch) {
					dfetch=true;
				}
				
				if((exc.opcode == 4 && branch) || exc.opcode == 7) {
					tobeprinted[2]+="PC is updated to "+pc+'\n';
					
				}
				if(exc.opcode == 4 && !branch) {
					tobeprinted[2]+="PC is not changed";
				}
				if(exc.opcode != 4 && exc.opcode!=7) {
					tobeprinted[2]+="Output is : "+exc.output+'\n';
				}
			
				mem = exc;
				mem.c=this;
				exc = null;
			}
			else {
				
				exc.timer--;
				tobeprinted[2]="";


				tobeprinted[2]+=	("Instruction in Execute stage is : "+exc.instr)+'\n';
				if(exc.opcode == 1 || exc.opcode == 2 || exc.opcode == 0 || exc.opcode ==5) {
					tobeprinted[2]+=	"Inputs are : Value of source register "+exc.valueR2+" and Value of target register "+exc.valueR3+'\n';
				}
				if(exc.opcode ==3) {
					tobeprinted[2]+=	"Input is immediate value: "+exc.imm+'\n';
				}
				if(exc.opcode == 6 || exc.opcode == 10 || exc.opcode == 11) {
					tobeprinted[2]+="Inputs : Value of source register "+exc.valueR2+" and immediate value "+exc.imm+'\n';
				}
				if(exc.opcode == 8 || exc.opcode == 9) {
					tobeprinted[2]+="Inputs : value of source register "+exc.valueR2+" and shift amount "+exc.shamt+'\n';
				}
				if(exc.opcode==7) {
					tobeprinted[2]+="Input : address = "+exc.addr+'\n';
					dfetch=true;
				}
				if(exc.opcode == 4) {
					tobeprinted[2]+="Input : Value of source register "+registerFile[exc.r1]+" and value of target register"+exc.valueR2+'\n';
				}
				
				tobeprinted[2]+="outputs not available yet"+'\n';
			}
		}
		else {
			
			
			tobeprinted[2]="";

			tobeprinted[2]+="No instruction in Execute stage"+'\n'+'\n';
			
		}
		if(ID != null) {
			if(ID.timer == 0) {
				ID.decode();
				tobeprinted[1]="";

				tobeprinted[1]+="Instruction in Decode stage is : "+ID.instr+'\n';
				tobeprinted[1]+="Input is : "+ID.instr+'\n';
				tobeprinted[1]+="Outputs are : "+'\n'+"opcode = "+ID.opcode+'\n';
				switch(ID.opcode) {
				case 0:
				case 1:
				case 2:
				case 5:
					tobeprinted[1]+="Value Source Register = "+ID.valueR2+
							"\n"+"Target Register = "+ID.valueR3+'\n';
					break;
				case 6:
				case 11:
				case 10:
					tobeprinted[1]+="Value of Source Register = "+ID.valueR2+"\n"+
				"Immediate Value = "+ID.imm+'\n';
					break;
				case 8:
				case 9:
					tobeprinted[1]+="Value Source Register = "+ID.valueR2+"\n"+
					"Shift value = "+ID.shamt+'\n';
					break;
				case 7:
			
					tobeprinted[1]+="Address = "+ID.addr+'\n';
					break;
				case 3:
					tobeprinted[1]+="Destination Register is R"+ ID.r1+"\n"+"Immediate value = "+ID.imm+'\n'+'\n';
					break;
				case 4: tobeprinted[1]+= "Source register: R"+ ID.r1+"\n"+" Target register: R"+ ID.r2+"\n"+ " immediate value: "+ID.imm+"\n";
					break;
				
				}
				
				exc = ID;
				exc.c=this;
				ID = null;
				exc.timer = 1; 
				IF = null;
			}
			else {


				ID.timer--;
				
				tobeprinted[1]="";

				tobeprinted[1]+="Instruction in Decode stage is : "+ID.instr+'\n';
				tobeprinted[1]+="Input is : "+ID.instr+'\n';
				tobeprinted[1]+="Output is not ready yet"+'\n';
				
			}
		}
		else {

			tobeprinted[1]="";

			tobeprinted[1]+="No Instruction in Decode stage"+'\n'+'\n';

		}
		
		if(IF == null && pc<count && !dfetch) {
			    IF = new ins();
			    IF.c=this;
				IF.fetch();

				tobeprinted[0]="";

				tobeprinted[0]+="Instruction in Fetch stage is : "+IF.instr+'\n';
				ID = IF;
				ID.c=this;
				ID.timer = 1;
				tobeprinted[0]+="Input is PC = "+(pc-1)+'\n';
				tobeprinted[0]+="Output is : "+IF.instr+'\n'+'\n';
				System.out.println(" ");
		}
		else {

			
			if(tobeprinted[0]==null) {
			tobeprinted[0]="";

			tobeprinted[0]+="No Instruction in Fetch stage "+'\n'+'\n';}

		}
		if(fetchJMP) {
			IF = new ins();
		    IF.c=this;
			IF.fetch();

			tobeprinted[0]="";

			tobeprinted[0]+="Instruction in Fetch stage is : "+IF.instr+'\n';
			tobeprinted[0]+="Input is PC = "+(pc-1)+'\n';
			tobeprinted[0]+="Output is : "+IF.instr+'\n'+'\n';
			ID = IF;
			ID.c=this;
			ID.timer = 1;
			fetchJMP = false;
			dfetch = false;
		}
		
		
	}
	public void Pipeline() throws Exception {
		cycles = 1;
		System.out.println("Cycle : "+cycles);
		Cycle();
		System.out.println(tobeprinted[0]);
		System.out.println(tobeprinted[1]);

		System.out.println(tobeprinted[2]);

		System.out.println(tobeprinted[3]);

		System.out.println(tobeprinted[4]);
		tobeprinted=new String[5];
	 while(IF != null || ID != null || exc != null || mem != null || wb != null) {
			cycles++;
			System.out.println("---------------------------------------------------------------------");
			System.out.println("Cycle : "+cycles);
			System.out.println(" ");
			Cycle();
			System.out.println(tobeprinted[0]);
			System.out.println(tobeprinted[1]);

			System.out.println(tobeprinted[2]);

			System.out.println(tobeprinted[3]);

			System.out.println(tobeprinted[4]);
			tobeprinted=new String[5];

			
		}
	 System.out.println("PC register = "+pc);
	 System.out.println(" ");
	 for(int i = 0;i<32;i++) {
		 System.out.println("R"+i+" = "+registerFile[i]);
	 }
	 System.out.println(" ");
	 for(int i = 0;i<1024;i++) {
		 System.out.println("Instruction Memory address: "+i+" = "+memory[i]);
	 }
	 System.out.println(" ");
	 for(int i =1024;i<2048;i++) {
		 System.out.println("Data Memory address: "+i+" = "+memory[i]);
	 }

		
	}
	public void instructions() throws Exception {
		Scanner input = new Scanner(new File("Instructions.txt"));
		int x =0;
		boolean Flag = false;
		String [] temp;
		int i =0;
		
		while(input.hasNext()) {
			s = input.nextLine()+" ";
			int instruction = 0;
			Flag = false;
			st = s.split(" ",2);
			count++;
			
			switch(st[0]) {
			case "ADD" :
				instruction = instruction | 0b00000000000000000000000000000000;
				break;
			case "SUB" :
				instruction = instruction | 0b00010000000000000000000000000000;
				break;
			case "MUL" :
				instruction = instruction | 0b00100000000000000000000000000000;
				break;
			case "MOVI" :
				instruction = instruction | 0b00110000000000000000000000000000;
				temp = st[1].split(" ",2);
				x = Integer.parseInt(temp[1].substring(0,temp[1].length()-1));
				x = x & 0b00000000000000111111111111111111;
				Flag = true;
				instruction = instruction | x;
				break;
			case "JEQ" :
				instruction = instruction | 0b01000000000000000000000000000000;
				break;
			case "AND" :
				instruction = instruction | 0b01010000000000000000000000000000;
				break;
			case "XORI" :
				instruction = instruction | 0b01100000000000000000000000000000;
				break;
			case "JMP" :
				instruction = instruction | 0b01110000000000000000000000000000;
				x = Integer.parseInt(st[1].substring(0,st[1].length()-1));
				instruction = instruction | x;
				break;
			case "LSL" :
				instruction = instruction | 0b10000000000000000000000000000000;
				break;
			case "LSR" :
				instruction = instruction | 0b10010000000000000000000000000000;
				break;
			case "MOVR" :
				instruction = instruction | 0b10100000000000000000000000000000;
				break;
			case "MOVM" :
				instruction = instruction | 0b10110000000000000000000000000000;
				break;
			}
			if(Flag == true) {
				temp = st[1].split(" ",2);
			}
			else {
				temp = st[1].split(" ",3);
			}
			switch(temp[0]) {
			case "R0" :
				instruction = instruction | 0b00000000000000000000000000000000;
				break;
			case "R1" :
				instruction = instruction | 0b00000000100000000000000000000000;
				break;
			case "R2" :
				instruction = instruction | 0b00000001000000000000000000000000;
				break;
			case "R3" :
				instruction = instruction | 0b00000001100000000000000000000000;
				break;
			case "R4" :
				instruction = instruction | 0b00000010000000000000000000000000;
				break;
			case "R5" :
				instruction = instruction | 0b00000010100000000000000000000000;
				break;
			case "R6" :
				instruction = instruction | 0b00000011000000000000000000000000;
				break;
			case "R7" :
				instruction = instruction | 0b00000011100000000000000000000000;
				break;
			case "R8" :
				instruction = instruction | 0b00000100000000000000000000000000;
				break;
			case "R9" :
				instruction = instruction | 0b00000100100000000000000000000000;
				break;
			case "R10" :
				instruction = instruction | 0b00000101000000000000000000000000;
				break;
			case "R11" :
				instruction = instruction | 0b00000101100000000000000000000000;
				break;
			case "R12" :
				instruction = instruction | 0b00000110000000000000000000000000;
				break;
			case "R13" :
				instruction = instruction | 0b00000110100000000000000000000000;
				break;
			case "R14" :
				instruction = instruction | 0b00000111000000000000000000000000;
				break;
			case "R15" :
				instruction = instruction | 0b00000111100000000000000000000000;
				break;
			case "R16" :
				instruction = instruction | 0b00001000000000000000000000000000;
				break;
			case "R17" :
				instruction = instruction | 0b00001000100000000000000000000000;
				break;
			case "R18" :
				instruction = instruction | 0b00001001000000000000000000000000;
				break;
			case "R19" :
				instruction = instruction | 0b00001001100000000000000000000000;
				break;
			case "R20" :
				instruction = instruction | 0b00001010000000000000000000000000;
				break;
			case "R21" :
				instruction = instruction | 0b00001010100000000000000000000000;
				break;
			case "R22" :
				instruction = instruction | 0b00001011000000000000000000000000;
				break;
			case "R23" :
				instruction = instruction | 0b00001011100000000000000000000000;
				break;
			case "R24" :
				instruction = instruction | 0b00001100000000000000000000000000;
				break;
			case "R25" :
				instruction = instruction | 0b00001100100000000000000000000000;
				break;
			case "R26" :
				instruction = instruction | 0b00001101000000000000000000000000;
				break;
			case "R27" :
				instruction = instruction | 0b00001101100000000000000000000000;
				break;
			case "R28" :
				instruction = instruction | 0b00001110000000000000000000000000;
				break;
			case "R29" :
				instruction = instruction | 0b00001110100000000000000000000000;
				break;
			case "R30" :
				instruction = instruction | 0b00001111000000000000000000000000;
				break;
			case "R31" :
				instruction = instruction | 0b00001111100000000000000000000000;
				break;
			}

			switch(temp[1]) {
			case "R0" :
				instruction = instruction | 0b00000000000000000000000000000000;
				break;
			case "R1" :
				instruction = instruction | 0b00000000000001000000000000000000;
				break;
			case "R2" :
				instruction = instruction | 0b00000000000010000000000000000000;
				break;
			case "R3" :
				instruction = instruction | 0b00000000000011000000000000000000;
				break;
			case "R4" :
				instruction = instruction | 0b00000000000100000000000000000000;
				break;
			case "R5" :
				instruction = instruction | 0b00000000000101000000000000000000;
				break;
			case "R6" :
				instruction = instruction | 0b00000000000011000000000000000000;
				break;
			case "R7" :
				instruction = instruction | 0b00000000000111000000000000000000;
				break;
			case "R8" :
				instruction = instruction | 0b00000000001000000000000000000000;
				break;
			case "R9" :
				instruction = instruction | 0b00000000001001000000000000000000;
				break;
			case "R10" :
				instruction = instruction | 0b00000000001010000000000000000000;
				break;
			case "R11" :
				instruction = instruction | 0b00000000001011000000000000000000;
				break;
			case "R12" :
				instruction = instruction | 0b00000000001100000000000000000000;
				break;
			case "R13" :
				instruction = instruction | 0b00000000001101000000000000000000;
				break;
			case "R14" :
				instruction = instruction | 0b00000000001110000000000000000000;
				break;
			case "R15" :
				instruction = instruction | 0b00000000001111000000000000000000;
				break;
			case "R16" :
				instruction = instruction | 0b00000000010000000000000000000000;
				break;
			case "R17" :
				instruction = instruction | 0b00000000010001000000000000000000;
				break;
			case "R18" :
				instruction = instruction | 0b00000000010010000000000000000000;
				break;
			case "R19" :
				instruction = instruction | 0b00000000010011000000000000000000;
				break;
			case "R20" :
				instruction = instruction | 0b00000000010100000000000000000000;
				break;
			case "R21" :
				instruction = instruction | 0b00000000010101000000000000000000;
				break;
			case "R22" :
				instruction = instruction | 0b00000000010110000000000000000000;
				break;
			case "R23" :
				instruction = instruction | 0b00000000010111000000000000000000;
				break;
			case "R24" :
				instruction = instruction | 0b00000000011000000000000000000000;
				break;
			case "R25" :
				instruction = instruction | 0b00000000011001000000000000000000;
				break;
			case "R26" :
				instruction = instruction | 0b00000000011010000000000000000000;
				break;
			case "R27" :
				instruction = instruction | 0b00000000011011000000000000000000;
				break;
			case "R28" :
				instruction = instruction | 0b00000000011100000000000000000000;
				break;
			case "R29" :
				instruction = instruction | 0b00000000011101000000000000000000;
				break;
			case "R30" :
				instruction = instruction | 0b00000000011110000000000000000000;
				break;
			case "R31" :
				instruction = instruction | 0b00000000011111000000000000000000;
				break;
			}
			
			if(temp.length > 2) {
				switch(temp[2]) {
				case "R0 " :
					instruction = instruction | 0b00000000000000000000000000000000;
					break;
				case "R1 " :
					instruction = instruction | 0b00000000000000000010000000000000;
					break;
				case "R2 " :
					instruction = instruction | 0b00000000000000000100000000000000;
					break;
				case "R3 " :
					instruction = instruction | 0b00000000000000000110000000000000;
					break;
				case "R4 " :
					instruction = instruction | 0b00000000000000001000000000000000;
					break;
				case "R5 " :
					instruction = instruction | 0b00000000000000001010000000000000;
					break;
				case "R6 " :
					instruction = instruction | 0b00000000000000000110000000000000;
					break;
				case "R7 " :
					instruction = instruction | 0b00000000000000001110000000000000;
					break;
				case "R8 " :
					instruction = instruction | 0b00000000000000010000000000000000;
					break;
				case "R9 " :
					instruction = instruction | 0b00000000000000010010000000000000;
					break;
				case "R10 " :
					instruction = instruction | 0b00000000000000010100000000000000;
					break;
				case "R11 " :
					instruction = instruction | 0b00000000000000010110000000000000;
					break;
				case "R12 " :
					instruction = instruction | 0b00000000000000011000000000000000;
					break;
				case "R13 " :
					instruction = instruction | 0b00000000000000011010000000000000;
					break;
				case "R14 " :
					instruction = instruction | 0b00000000000000011100000000000000;
					break;
				case "R15 " :
					instruction = instruction | 0b00000000000000011110000000000000;
					break;
				case "R16 " :
					instruction = instruction | 0b00000000000000100000000000000000;
					break;
				case "R17 " :
					instruction = instruction | 0b00000000000000100010000000000000;
					break;
				case "R18 " :
					instruction = instruction | 0b00000000000000100100000000000000;
					break;
				case "R19 " :
					instruction = instruction | 0b00000000000000100110000000000000;
					break;
				case "R20 " :
					instruction = instruction | 0b00000000000000101000000000000000;
					break;
				case "R21 " :
					instruction = instruction | 0b00000000000000101010000000000000;
					break;
				case "R22 " :
					instruction = instruction | 0b00000000000000101100000000000000;
					break;
				case "R23 " :
					instruction = instruction | 0b00000000000000101110000000000000;
					break;
				case "R24 " :
					instruction = instruction | 0b00000000000000110000000000000000;
					break;
				case "R25 " :
					instruction = instruction | 0b00000000000000110010000000000000;
					break;
				case "R26 " :
					instruction = instruction | 0b00000000000000110100000000000000;
					break;
				case "R27 " :
					instruction = instruction | 0b00000000000000110110000000000000;
					break;
				case "R28 " :
					instruction = instruction | 0b00000000000000111000000000000000;
					break;
				case "R29 " :
					instruction = instruction | 0b00000000000000111010000000000000;
					break;
				case "R30 " :
					instruction = instruction | 0b00000000000000111100000000000000;
					break;
				case "R31 " :
					instruction = instruction | 0b00000000000000111110000000000000;
					break;
				default : 
					x = Integer.parseInt(temp[2].substring(0,temp[2].length()-1));
					instruction = instruction | x;
				}
			}
			
			memory[i] = instruction;
			i++;
			
		}

		
	}
	public static void main(String[]args) throws Exception {
		Computer m = new Computer();
		m.memory[1026]=22;
		m.instructions();
		m.Pipeline();

		
		
	}


}
